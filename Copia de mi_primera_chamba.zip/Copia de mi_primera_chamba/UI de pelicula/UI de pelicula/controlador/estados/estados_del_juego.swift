//
//  estados_juego.swift
//  mi_primera_chamba
//
//  Created by Jadzia Gallegos on 12/09/25.
//

/// Recuerda agregar un estado de perdiste
///
enum EstadosJuego{
    case esta_jugando
    case ha_ganado
}
