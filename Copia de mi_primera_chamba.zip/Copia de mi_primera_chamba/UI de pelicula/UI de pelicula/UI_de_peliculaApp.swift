//
//  UI_de_peliculaApp.swift
//  UI de pelicula
//
//  Created by Miguel Angel Longoria Granados on 16/09/25.
//

import SwiftUI

@main
struct UI_de_peliculaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
